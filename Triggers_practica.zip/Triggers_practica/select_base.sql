SELECT * FROM clientes;

SELECT * FROM proveedores;
SELECT * FROM categorias; 
guardarcategorias_eliminadaSELECT * FROM categorias_auditoria;

SELECT * FROM productos; 

CREATE TABLE `productos_auditoriastock` (
  `id_auditoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_audi` varchar(50) NOT NULL,
  `precio_audi` double NOT NULL,
  `stock_audi` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_auditoria`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`),
  CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


guardarcategorias_eliminadaguardarcategorias_eliminada

categorias_auditoria show triggers from supermercado;

set sql_safe_updates=0;


DELETE FROM productos WHERE id_categoria = 3;
DELETE FROM productos WHERE id_categoria = 2;







CREATE TABLE `clientes_auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
