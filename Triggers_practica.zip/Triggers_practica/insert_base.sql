
INSERT INTO proveedores (nombre, direccion, telefono, web) VALUES
('Distribuciones Mixtas S.A.', 'Av. Siempre Viva 123, Colombia', '+573003790400', 'https://www.distribucionesglobales.com'),
('TecnoParts Ltda.', 'Calle 45 #10-25, Bogotá, Colombia', '+57 1 654 3210', 'https://www.tecnoparts.co'),
('Industrias Sol S.R.L.', 'Av. del Sol 567, Buenos Aires, Argentina', '+54 11 4321 8765', 'https://www.industriassol.com.ar'),
('Suministros del Norte', 'Calle Real 89, Monterrey, México', '+52 81 9988 7766', 'https://www.suministrosnorte.mx'),
('Proveedora Andina', 'Jr. Los Laureles 210, Lima, Perú', '+51 1 334 5566', 'https://www.proveedoraandina.pe');

INSERT INTO proveedores (nombre, direccion, telefono, web) VALUES
('Distribuciones Mixtas S.A.', 'Av. Siempre Viva 123, Colombia', '+573003790400', 'https://www.distribucionesglobales.com');

INSERT INTO categorias (nombre, descripcion) VALUES
('Bebidas', 'Gaseosas, jugos, aguas'),
('Alimentos', 'Comestibles no perecederos'),
('Limpieza', 'Productos de aseo personal y hogar');

INSERT INTO clientes
(nombre,apellido,email,telefono,direccion)
VALUES 
('María', 'González', 'maria.gonzalez@example.com', '+57300', 'La Esmeralda'),
('Juan', 'Pérez', 'juan.perez@example.com', '+57312', 'Calle 10 #25-30, La paz'),
('Lucía', 'Fernández', 'lucia.fernandez@example.com', '+54320', 'Av. 17 la Esmeralda'),
('Carlos', 'Ramírez', 'carlos.ramirez@example.com', '+57310', 'Calle 12 #25-30, La paz'),
('Sofía', 'Martínez', 'sofia.martinez@example.com', '+57301', 'Calle 10 #25-30, Empedrado');


INSERT INTO clientes (nombre, apellido, email, telefono, direccion) VALUES
('Marta', 'Gutierrez', 'marta.gonzalez@example.com', '+573103790422', 'Av. Reforma 123, Ciudad de México'),
('David', 'Paz', 'David.perez@example.com', '+573203890422', 'Av. Corrientes 450, Buenos Aires, Argentina'),
('Carla', 'Riascos', 'carla.ramirez@example.com', '+573003790422', 'Jr. Los Olivos 120, Lima, Perú'),
('Sandra', 'Maca', 'sandra.martinez@example.com', '+573003790422', 'Av. Providencia 900, Santiago, Chile');


INSERT INTO productos
(nombre,precio,stock,id_categoria,id_proveedor)
VALUES
();

INSERT INTO productos (nombre, precio, stock, id_categoria, id_proveedor) VALUES
('Mouse inalámbrico Logitech M185', 250.00, 45, 1, 2),
('Teclado mecánico Redragon Kumara', 520.00, 30, 1, 2),
('Monitor Samsung 24" Full HD', 1750.00, 20, 2, 1),
('Disco SSD Kingston 480GB', 890.00, 60, 3, 3),
('Impresora HP DeskJet 2720', 1350.00, 15, 1, 3);


INSERT INTO detalles_venta
(id_venta,id_producto,cantidad,precio_unitario)
VALUES();

INSERT INTO ventas
(fecha,total_venta,id_cliente)
VALUES();

CREATE TABLE `categorias_auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `precio` double NOT NULL,
  `stock` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id`),
  CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

