DELIMITER //
CREATE TRIGGER guardarcategorias_eliminada
BEFORE DELETE ON categorias FOR EACH ROW
BEGIN
INSERT INTO categorias_auditoria(id,nombre,descripcion)
VALUES(OLD.id,OLD.nombre,OLD.descripcion);
END //
DELIMITER ; guardarcategorias_eliminada





DELIMITER //
CREATE TRIGGER guardaraccionesnueva
AFTER INSERT ON proveedores FOR EACH ROW
BEGIN
INSERT INTO acciones(accion)
VALUES(concat("se creo un nuevo proveedor",NEW.nombre));
END //
DELIMITER ; 

DELIMITER //
CREATE TRIGGER after_insert_clientes
AFTER INSERT ON clientes
FOR EACH ROW
BEGIN
INSERT INTO auditoria_clientes (accion, id_cliente)
VALUES ('INSERT', NEW.id);
END
DELIMITER //

DELIMITER //
CREATE TRIGGER after_delete_clientes
AFTER DELETE ON clientes
FOR EACH ROW
BEGIN
INSERT INTO auditoria_clientes (accion, id_cliente)
VALUES ('DELETE', OLD.id);
END
DELIMITER //
