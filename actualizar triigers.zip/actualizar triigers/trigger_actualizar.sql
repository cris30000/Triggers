-- para registrar cambios o actualizaciones de precios tenemos la tabla

CREATE TABLE bitacora_actualizaciones (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT,
    campo_modificado VARCHAR(50),
    valor_anterior VARCHAR(100),
    valor_nuevo VARCHAR(100),
    fecha_modificacion DATETIME
);
-- y luego ejecutamos el trigger el cual antes de actualizar compara los valores antiguos con los nuevos y si hay cambios los registra

DELIMITER $$

CREATE TRIGGER trg_bitacora_update
BEFORE UPDATE ON productos
FOR EACH ROW
BEGIN
    IF OLD.precio <> NEW.precio THEN
        INSERT INTO bitacora_actualizaciones (id_producto, campo_modificado, valor_anterior, valor_nuevo, fecha_modificacion)
        VALUES (OLD.id_producto, 'precio', OLD.precio, NEW.precio, NOW());
    END IF;
    
    IF OLD.stock <> NEW.stock THEN
        INSERT INTO bitacora_actualizaciones (id_producto, campo_modificado, valor_anterior, valor_nuevo, fecha_modificacion)
        VALUES (OLD.id_producto, 'stock', OLD.stock, NEW.stock, NOW());
    END IF;
END $$

DELIMITER ;
