-- realizando cambios con ejemplos

UPDATE productos
SET precio = 2600000
WHERE id_producto = 1;

UPDATE productos
SET stock = stock + 10
WHERE id_producto = 3;

UPDATE productos
SET stock = stock + 5
WHERE id_producto = 2;
 
 
 -- consuulto si se ejecuto el trigger
 SELECT * FROM bitacora_actualizaciones;


-- otro ejemplo de eliminacion consulto la tabla productos
SELECT * FROM productos;

-- elimino un producto
DELETE FROM productos
WHERE id_producto = 2;

-- consuto mi bitacora de eliminacion

SELECT * FROM bitacora_eliminaciones;

SHOW TABLES;

DELETE FROM productos WHERE id_producto = 5;

-- 1️ Verifica si está en ventas
SELECT * FROM detalle_ventas WHERE id_producto = 5;

-- 2️⃣ Elimina los registros dependientes
DELETE FROM detalle_ventas WHERE id_producto = 5;

-- 3Elimina el producto (activará el trigger de bitácora)
DELETE FROM productos WHERE id_producto = 5;

-- 4️ Verifica el registro en la bitácora
SELECT * FROM bitacora_eliminaciones;

