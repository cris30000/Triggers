INSERT INTO proveedores (nombre, telefono, direccion)
VALUES
('Distribuidora La Excelencia', '3214567890', 'Calle 45 #12-34, Bogotá'),
('Tech Import S.A.', '3109876543', 'Av. 80 #45-67, Medellín'),
('Papelería Mundial', '3001234567', 'Cra. 23 #56-89, Cali');



INSERT INTO productos (nombre, descripcion, precio, stock)
VALUES
('Laptop Lenovo', 'Laptop Lenovo IdeaPad 15.6"', 2500000, 10),
('Mouse inalámbrico Logitech', 'Mouse óptico inalámbrico USB', 80000, 50),
('Teclado Mecánico Redragon', 'Teclado retroiluminado gamer', 180000, 30),
('Memoria USB 64GB', 'Memoria flash 3.0', 45000, 100),
('Monitor Samsung 24"', 'Monitor LED Full HD', 600000, 20);


INSERT INTO clientes (nombre, email, telefono)
VALUES
('Juan Pérez', 'juanperez@gmail.com', '3112233445'),
('María Gómez', 'maria.gomez@hotmail.com', '3005566778'),
('Carlos Rodríguez', 'c.rodriguez@yahoo.com', '3128899001');


INSERT INTO ventas (id_cliente)
VALUES
(1),
(2),
(3);


INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, precio_unitario)
VALUES
(1, 1, 1, 2500000),  -- Juan compra una laptop
(1, 2, 2, 80000),    -- Juan compra 2 mouse
(2, 5, 1, 600000),   -- María compra un monitor
(3, 4, 3, 45000),    -- Carlos compra 3 memorias USB
(3, 3, 1, 180000);   -- Carlos compra un teclado


