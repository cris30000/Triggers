-- creo la tabla que almacenara los productos eliminados

CREATE TABLE bitacora_eliminaciones (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT,
    nombre_producto VARCHAR(100),
    fecha_eliminacion DATETIME
);

-- creo el trigger que registra la eliminacion, este se activa antes de eliminar el producto inserta en la tabla bitacora el ID , la fecha y hira
DELIMITER $$

CREATE TRIGGER trg_bitacora_eliminacion
BEFORE DELETE ON productos
FOR EACH ROW
BEGIN
    INSERT INTO bitacora_eliminaciones (id_producto, nombre_producto, fecha_eliminacion)
    VALUES (OLD.id_producto, OLD.nombre, NOW());
END $$

DELIMITER ;
