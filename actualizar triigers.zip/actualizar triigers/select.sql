SELECT * FROM productos;
